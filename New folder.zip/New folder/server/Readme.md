https://newsdata.io/api/1/news?apikey=pub_109711025d2f392ba357f851f88ba1b9c20dc&q=cricket

Hey i am adding