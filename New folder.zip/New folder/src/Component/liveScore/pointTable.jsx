import React from "react";
import { NavbarLive } from "./navbar";
export const PonitTable = () => {
  return (
    <>
      <NavbarLive />
      <h1>Point Table</h1>
    </>
  );
};
