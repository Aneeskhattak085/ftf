import React from "react"

import { themecontext } from "../context/themecontext"
import { Carousel } from '@trendyol-js/react-carousel';

export const LiveScoreBox=()=>{
     const {theme,handleTheme}=React.useContext(themecontext);
    
return <div>
</div>
}